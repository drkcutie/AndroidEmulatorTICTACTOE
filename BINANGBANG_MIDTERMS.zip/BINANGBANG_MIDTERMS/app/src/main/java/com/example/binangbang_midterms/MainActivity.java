package com.example.binangbang_midterms;

import static android.graphics.Color.BLUE;
import static android.graphics.Color.GRAY;
import static android.graphics.Color.RED;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import kotlinx.coroutines.TimeoutCancellationException;

public class MainActivity extends AppCompatActivity {


    TextView playerturn;
    Boolean isFull = false;

    char TicTacToe[][];
    Button view1, view2, view3, view4, view5, view6, view7, view8, view9;

    char turn ;
    LinearLayout container;

    public void initialize() {
        turn = 'O';
        TicTacToe = new char[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                TicTacToe[i][j] = 'E';
            }
        }
        playerturn.setText("Player O's turn");
        container.setBackgroundColor(BLUE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "BINANGBANG, DERRICK C. - TICTACTOE ACTIVITY", Toast.LENGTH_SHORT).show();
        container = findViewById(R.id.layoutContainer);
        playerturn = findViewById(R.id.playerTurn);
        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        view3 = findViewById(R.id.view3);
        view4 = findViewById(R.id.view4);
        view5 = findViewById(R.id.view5);
        view6 = findViewById(R.id.view6);
        view7 = findViewById(R.id.view7);
        view8 = findViewById(R.id.view8);
        view9 = findViewById(R.id.view9);
        reset();
        view1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[0][0] == 'E') {
                    view1.setText(turn + "");
                    view1.setClickable(false);
                    TicTacToe[0][0] = turn;
                    System.out.println("TURN IS " + turn);
                }
                 changeState();
            }
        });

        view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[0][1] == 'E') {
                    view2.setText(turn + "");
                    view2.setClickable(false);
                    TicTacToe[0][1] = turn;
                }
                changeState();
                gameOver();

            }
        });
        view3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[0][2] == 'E') {
                    view3.setText(turn + "");
                    view3.setClickable(false);
                    TicTacToe[0][2] = turn;
                }
                changeState();
                gameOver();
            }
        });
        view4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[1][0] == 'E') {
                    view4.setText(turn + "");
                    view4.setClickable(false);
                    TicTacToe[1][0] = turn;
                }
                changeState();
                gameOver();
            }
        });
        view5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[1][1] == 'E') {
                    view5.setText(turn + "");
                    view5.setClickable(false);
                    TicTacToe[1][1] = turn;
                }
                changeState();
                gameOver();
            }
        });
        view6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[1][2] == 'E') {
                    view6.setText(turn + "");
                    view6.setClickable(false);
                    TicTacToe[1][2] = turn;
                }
                changeState();
                gameOver();
            }
        });
        view7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[2][0] == 'E') {
                    view7.setText(turn + "");
                    view7.setClickable(false);
                    TicTacToe[2][0] = turn;
                }
                changeState();
                gameOver();
            }
        });
        view8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[2][1] == 'E') {
                    view8.setText(turn + "");
                    view8.setClickable(false);
                    TicTacToe[0][1] = turn;
                }
                changeState();
                gameOver();
            }
        });
        view9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TicTacToe[2][2] == 'E') {
                    view9.setText(turn + "");
                    view9.setClickable(false);
                    TicTacToe[0][1] = turn;
                }
                changeState();
                gameOver();
            }
        });


    }
    public  void reset()
    {
        initialize();
        turn = 'O';
        Button buttons[] = {view1,view2,view3,view4,view5,view6,view7,view8,view9};
        for(Button button: buttons)
        {
            button.setText("");
            button.setClickable(true);
            button.setBackgroundColor(GRAY);
        }
    }
    public void noOneWon()
    {
        Toast.makeText(this, "GAME OVER! DRAW", Toast.LENGTH_SHORT).show();
        reset();
    }
    public void gameOver(){
        boolean state = false;

        if(state)
        {
            Toast.makeText(this, "GAME OVER! PLAYER " + turn + " wins" , Toast.LENGTH_SHORT).show();
//            try {
//                Thread.sleep( 5000);
//            }catch (Exception e)
//            {
//
//            }
            reset();

        }else if(isFull)
        {
            noOneWon();
        }
    }
    public boolean checkBingo() {

        boolean row = false;
        boolean col = false;
        boolean diag = false;

        //Row Checker
        for (int i = 0; i < 3; i++) {
            char temp = TicTacToe[i][0];
            row = false;
            for (int j = 0; j < 3; j++) {
                if (TicTacToe[i][j] != temp) {
                    row = false;
                    break;
                }
                else if(TicTacToe[i][j] != 'E')
                {
                    row = true;
                }
            }
            if(row)
                return true;
        }


        //Col Checker
        for (int i = 0; i < 3; i++) {
            char temp = TicTacToe[0][i];
            for (int j = 0; j < 3; j++) {
                if (TicTacToe[j][i] != temp) {
                    col = false;
                    break;
                }
                else if(TicTacToe[j][i] != 'E')
                {

                    col = true;
                }
            }
            if(col)
                return true;
        }
        //Diagonal Checker
        if (TicTacToe[0][0] != 'E' && TicTacToe[0][0] == TicTacToe[1][1] && TicTacToe[2][2] == TicTacToe[1][1]) {
            return true;
        } else if (TicTacToe[0][2] != 'E'&&TicTacToe[0][2] == TicTacToe[1][1] && TicTacToe[2][0] == TicTacToe[1][1]) {
            return true;
        }

        int ctr = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (TicTacToe[i][j] != 'E') {
                    ctr++;
                }
            }
        }
        if(ctr == 9)
        {
            isFull = true;
        }
        return false;
    }

    public void changeState() {
        turn = turn == 'O'? 'X': 'O';

        if (turn == 'O')
            container.setBackgroundColor(BLUE);
        else
            container.setBackgroundColor(RED);
        System.out.println(turn);
        
        playerturn.setText("Player " + turn + "'s turn");
    }


}